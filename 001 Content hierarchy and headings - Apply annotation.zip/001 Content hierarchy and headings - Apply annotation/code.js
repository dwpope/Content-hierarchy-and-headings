"use strict";
// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).
// This plugin creates annotation instances on the screen.
const nodes = [];
// Import only the annotation component
figma.importComponentByKeyAsync('4accb572e7d08cd3d67d459e831a3eb4a536d66d') // Replace with actual annotation component key
    .then(annotationComponent => {
    // Create an Annotation instance for each selected node.
    figma.currentPage.selection.forEach(node => {
        const absoluteBoundingBox = node.absoluteBoundingBox;
        if (absoluteBoundingBox) {
            // Create Annotation instance
            const annotationInstance = annotationComponent.createInstance();
            annotationInstance.name = "Annotation";
            // Append the annotation instance to the page
            figma.currentPage.appendChild(annotationInstance);
            // Position annotation to the centre left of the selected node with 8px spacing
            annotationInstance.x = absoluteBoundingBox.x - annotationInstance.width - 8; // placed to left with 8px spacing
            annotationInstance.y = absoluteBoundingBox.y + (node.height / 2) - (annotationInstance.height / 2); // vertically centered relative to the selected node
            // Add the annotation instance to the nodes array
            nodes.push(annotationInstance);
        }
    });
    // Update selection and viewport
    figma.currentPage.selection = nodes;
    figma.viewport.scrollAndZoomIntoView(nodes);
    // Close the plugin
    figma.closePlugin();
})
    .catch(error => {
    // Handle any errors (e.g., component not found)
    figma.notify(`Error: ${error.message}`);
    figma.closePlugin();
});
